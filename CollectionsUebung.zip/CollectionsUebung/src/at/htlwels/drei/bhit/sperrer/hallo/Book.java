package at.htlwels.drei.bhit.sperrer.hallo;

/**
 * Created by Sperrer Daniel on 25.11.2016.
 */
public class Book {

    private String author;
    private String title;
    private Integer issue;

    public Book(String author,String title,Integer issue)
    {
        this.author=author;
        this.title=title;
        this.issue=issue;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getIssue() {
        return issue;
    }

    public void setIssue(Integer issue) {
        this.issue = issue;
    }
}
